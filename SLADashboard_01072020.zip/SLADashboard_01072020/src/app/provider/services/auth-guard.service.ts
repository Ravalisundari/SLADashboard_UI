import { Injectable } from '@angular/core';
import { CanActivate, Router,ActivatedRouteSnapshot } from '@angular/router';
import { AuthenticationService } from '../services/authentication.service';

@Injectable({
  providedIn: 'root'
})
export class AuthGuardService implements CanActivate {

  constructor(private router: Router, private authService: AuthenticationService) { }

  canActivate(route: ActivatedRouteSnapshot) {
   /* if (!this.authService.isTokenExpired()) {
      return true;
    }
    this.router.navigate(['/login']);
    return false;*/
    console.log("I am called in call activate")
    var currentUser = this.authService.getUserDetails();
    if (currentUser) {
        // check if route is restricted by role
        console.log("I am called in router")
        if (route.data.roles && route.data.roles.indexOf(currentUser.sid) === -1) {
            // role not authorised so redirect to home page
            this.router.navigate(['/']);
            return false;
        }

        // authorised so return true
        return true;
    }

    // not logged in so redirect to login page with the return url
    console.log("I am not logged in")
    this.router.navigate(['/login']);
    return false;
  }
}

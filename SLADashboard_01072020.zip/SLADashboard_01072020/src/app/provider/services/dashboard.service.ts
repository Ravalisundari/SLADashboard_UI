import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, forkJoin } from 'rxjs';
import { map } from 'rxjs/operators';
import { User } from '../models/user';
import { OpeningTimes } from '../models/openingTimes';
import { BankHolidayDetails } from '../models/bankHolidayDetails';


@Injectable({ providedIn: 'root' })
export class DashboardService {
  selectedCallFlow: string;
  private serviceUrl = "https://localhost:44362/api/";
  userCredentials: User;

  constructor(private http: HttpClient) { }

  setCallFlow(value) {
    this.selectedCallFlow = value;
  }

  getCallFlow() {
    return this.selectedCallFlow;
  }

  getUserManagementDetails(): Observable<any> {
    return this.http.get<any>(this.serviceUrl + "UserManagement")
      .pipe(map(user => {
        return user
      }));
  }

  getTeams(): Observable<any> {
    let teamName = this.http.get(this.serviceUrl + "CallFlow/Teams");
    let callFlow = this.http.get(this.serviceUrl + "CallFlow");
    return forkJoin([teamName, callFlow]).pipe(map((resspone: any) => {
      console.log(resspone)
      return resspone;
    }));
  }

  getOpeningTimes(callFlowId: string): Observable<any> {
    return this.http.get(this.serviceUrl + "OpeningTimes?callFlowId=" + callFlowId)
      .pipe(map((response: any) => {
        return response;
      }));
  }

  updateOpeningTimes(openingTimesModel: OpeningTimes): Observable<any> {
    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    return this.http.post<any>(this.serviceUrl + "OpeningTimes", openingTimesModel, { headers: headers })
      .pipe(map((response: any) => {
        console.log(response);
      }));
  }

  getHolidays(callFlowId: string): Observable<any> {
    let bankHolidayEnabled = this.http.get(this.serviceUrl + "BankHoliday/BankHolidayEnabled?callFlowId=" + callFlowId);
    let bankHolidayDetails = this.http.get(this.serviceUrl + "BankHoliday/BankHolidayDetails?callFlowId=" + callFlowId);
    return forkJoin([bankHolidayEnabled, bankHolidayDetails]).pipe(map((response: any) => {
      return response;
    }));
  }

  updateHolidays(bankHolidayDetails: BankHolidayDetails, callFlowId: string): Observable<any> {
    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    return this.http.post<any>(this.serviceUrl + "BankHoliday?callFlowId=" + callFlowId, bankHolidayDetails, { headers: headers })
      .pipe(map((response: any) => {
        console.log(response);
      }));
  }
}
import { Component, OnInit } from '@angular/core';
import { DashboardService } from 'src/app/provider/services/dashboard.service';
import { BankHolidayDetails, BankHolidayEnabled } from 'src/app/provider/models/bankHolidayDetails';

@Component({
  selector: 'app-holidays',
  templateUrl: './holidays.component.html',
  styleUrls: ['./holidays.component.css']
})
export class HolidaysComponent implements OnInit {

  IndividualMessages: boolean;
  checkHolidayDays: boolean;
  bankHolidayEnabled: BankHolidayEnabled;
  bankHolidayDetails: BankHolidayDetails;
  newBankHolidayDetails: BankHolidayDetails;
  callFlowId: string = "11";

  Holidays = [
    { date: '25/12/2019', start: '10:10', end: '23:00', close: true },
    { date: '08/12/2019', start: '09:46', end: '22:00', close: false },
    { date: '07/12/2019', start: '08:10', end: '21:00', close: true }
  ]

  constructor(private dashboardService: DashboardService) { }

  ngOnInit() {

    this.getHolidays();

    /* this.holidayservice.GetHolidayDetails().subscribe(
       data => this.Holiday = data );*/
  }

  Remove(a) {
    this.Holidays.splice(a, 1);
  }

  getHolidays() {
    this.dashboardService.getHolidays(this.callFlowId).subscribe((data: any) => {
      console.log(data);
      this.bankHolidayEnabled = data[0];
      this.bankHolidayDetails = data[1];
    });
  }

  updateHolidays() {
    this.newBankHolidayDetails = this.bankHolidayDetails; //updated holidays list to be assigned to newBankHolidaysDetails
    this.dashboardService.updateHolidays(this.newBankHolidayDetails, this.callFlowId).subscribe();
  }

}

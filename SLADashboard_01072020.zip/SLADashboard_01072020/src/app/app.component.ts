import { Component } from '@angular/core';
import {DashboardService} from '../app/provider/services/dashboard.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'SLAapplication';
  callFlow:string;
  constructor(private dashboardService:DashboardService){}
  ngOnInit(){
    console.log("I am in header");
  }
}
